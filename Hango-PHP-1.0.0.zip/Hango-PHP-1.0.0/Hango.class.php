<?php
	class Hango{
		/**
		 * @description Cette classe vous permet d'interagir avec l'application Hango
		 * vous permettant d'envoyer des SMS à partir d'Internet se servant 
		 * de vos numeros personnalisés
		 * 
		 * Ce systeme utilise CURL, donc, rassurez vous que vous avez CURL installé 
		 * sur votre serveur Apache.
		 * 
		 * @copyright nfinic
		 * @author Mathe Eliel
		 */
		 
		 /**
		  * @param code_application String Code de l'application obtenu sur le site
		  * @param adresse_email String Votre adresse email, celui de votre compte
		  */
		 private $code_application;
		 private $adresse_email;
		 private $lienEnvoi = "http://socket.nfinic.com/sender.php";
		 
		 public function __construct($code_application,$email){
		 	if(!empty($code_application) and !empty($email)){
		 		$this -> code_application = $code_application;
				$this -> adresse_email = $email;
		 	}else "N6";		 	
		 }
		 
		 /**
		  * @param destinataires String Liste des numeros destinataires separés par par des virgules
		  * @param adressse_email String Contenu du message à envoyer aux personnes de choix
		  * @return succes String Si l'envoi c'est effectuée avec succès et false, sinon 
		  */
		  
		 public function envoyerMessage($destinataires,$message){
		 	if(!empty($destinataires) and !empty($message)){
		 		$_hango = array();
		 		$_hango['email'] = $this -> adresse_email;
				$_hango['code'] = $this -> code_application;
				$_hango['message'] = $message;
				$_hango['numeros'] = $destinataires;
				$_hango['act'] = 1;
				
				$ch = curl_init();
				$champs = http_build_query($_hango);
				
				curl_setopt($ch, CURLOPT_URL, $this -> lienEnvoi);
				curl_setopt($ch, CURLOPT_POST,count($_hango));
				curl_setopt($ch, CURLOPT_POSTFIELDS, $champs);
				curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				
				$result = curl_exec($ch);
				curl_close($ch);
				
				return $result;
		 	}else return "E5";
		 }
		 
		 /**
		  * @param destinataires Array Liste des numeros destinataires, un par element du tableau
		  * @param adressse_email String Contenu du message à envoyer aux personnes de choix
		  * @return succes String Si l'envoi c'est effectuée avec succès et false, sinon
		  */
		 public function envoyerMessageTableauDestinataire($destinataires,$message){
		 	if(!empty($destinataires) and !empty($message)){
		 		if(is_array($destinataires)){
		 			$lesDestinataires = $this -> obtenirNoms($destinataires);
					unset($destinataires);
					if(!empty($lesDestinataires) and $lesDestinataires != ""){
						envoyerMessage($lesDestinataires,$message);
					}else return "A3";
		 		}else return "D2";
		 	}else return "C1";
		 }
		 
		 private function obtenirNoms($liste){
		 	if(!empty($liste) and is_array($liste)){
		 		$laListe = "";
		 		for($i = 0;$i < count($liste);$i++){
		 			if($i == 0) $laListe = $liste[$i];
					else $laListe[$i] .= ",".$liste[$i];
		 		}
				return $laListe;
			}else return "L4";
		 }
		 
		 /**
		  * LISTE DES ERREURS
		  * C1: Il y a des champs non completés
		  * D2: Destinataire n'est pas un tableau
		  * A3: Aucun destinataire choisi.
		  * L4: Pas de liste selectionnee
		  * E5: Echec d'envoi du message
		  * N6: Champs non completés
		  */
	}
